## v1.0.5
- Fixed Issue #25 Mini button with icon alignment issue
- Fixed Issue #24 Checkbox and radio button toggles not obvious
- Fixed issue #23 Striped progress bars not repeated
- Fixed issue #19 Different height between button


## v1.0.4
- Fixed issue 10 Alert info links style
- Fixed issue 11 Emphasis classes are all white
- Fixed issue 13 Menu Card on Left SideBar
- Fixed issue 22 Fixed responsive


## v1.0.3
- Fixed issue #9
- Upgraded Font-Awesome to v3.2.1
- Upgraded Recess to v1.1.8

## v1.0.2
- fixed Validation states (Forms)
- Fixed Issue #4 "Button rework .."
- added bootstrap version in the header of .css
- Fixed examples
- Added instruction on how to properly reference Font-Awesome.

## v1.0.1
- Fixed Issue #1: appended/prepended not aligned with input

## v1.0.0
- **Initial release**